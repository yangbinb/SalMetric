import torch
import torchvision.transforms as transforms
import numpy as np
from torch.utils import data
import os
import os.path
from PIL import Image
import custom_transforms as tr

IMG_EXTENSIONS = [
    '.jpg', '.JPG', '.jpeg', '.JPEG',
    '.png', '.PNG', '.ppm', '.PPM', '.bmp', '.BMP',
]


def is_image_file(filename):
    return any(filename.endswith(extension) for extension in IMG_EXTENSIONS)


def make_dataset(dir):
    images = []
    assert os.path.isdir(dir), '%s is not a valid directory' % dir

    for root, _, fnames in sorted(os.walk(dir)):
        for fname in fnames:
            if is_image_file(fname):
                path = os.path.join(root, fname)
                images.append(path)
    return images


class MyDataloader(data.Dataset):
    def __init__(self, rgb_path, data_type):
        self.input_size = 400
        self.data_type = data_type

        # self.normalize = transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])

        self.train_transform = transforms.Compose([
            tr.FixedResize(size=(self.input_size + 8, self.input_size + 8)),
            tr.RandomCrop(size=(self.input_size, self.input_size)),
            tr.RandomHorizontalFlip(),
            tr.RandomRotateOrthogonal(),
            tr.Normalize(mean=(0.485, 0.456, 0.406), std=(0.229, 0.224, 0.225)),
            tr.ToTensor()])

        self.val_test_transform = transforms.Compose([
            tr.FixedResize(size=(self.input_size, self.input_size)),
            tr.Normalize(mean=(0.485, 0.456, 0.406), std=(0.229, 0.224, 0.225)),
            tr.ToTensor()])

        # self.train_transform = transforms.Compose([
        #     transforms.RandomResizedCrop(self.input_size, scale=(0.2, 1.0)),
        #     transforms.RandomHorizontalFlip(),
        #     transforms.ToTensor()
        # ])
        # self.val_test_transform = transforms.Compose([
        #     transforms.Resize(int(self.input_size/0.875)),
        #     transforms.CenterCrop(self.input_size),
        #     transforms.ToTensor()
        # ])
        # self.rgb_transform = transforms.Compose([
        #     transforms.ToTensor(),
        #     transforms.Normalize((0.485, 0.456, 0.406), (0.229, 0.224, 0.225))
        # ])
        # self.mask_transform = transforms.Compose([transforms.ToTensor()])
        # self.img_size = img_size if isinstance(img_size, tuple) else (img_size, img_size)
        self.rgb_files = make_dataset(rgb_path)

    def __len__(self):
        return len(self.rgb_files)

    def __getitem__(self, index):
        # put all the RGB images into one folder, and mask into another folder
        rgb_path = self.rgb_files[index]
        # you can save the path of RGB image of its mask into a file
        mask_path = rgb_path.replace('imgs', 'gt')

        rgb_img = Image.open(rgb_path).convert('RGB')
        mask = Image.open(mask_path)

        #resize each image into128*128
        # rgb_img = rgb_img.resize((128,128), Image.BICUBIC)
        # rgb_img = rgb_img.resize((224, 224), Image.BICUBIC)

        #must use NEARESTn method when resizing the mask
        # mask = mask.resize((128,128), Image.NEAREST)
        # mask = mask.resize((224, 224), Image.NEAREST)

        # mask = np.array(mask)
        # mask = mask[:, :]
        # mask[mask != 255] = 0
        # mask[mask == 255] = 1  # interchange the white color and black color, white color is the background color

        raw_data = {'image': rgb_img, 'label': mask}
        if self.data_type == 'train':
            normalized_data = self.train_transform(raw_data)
        elif self.data_type == 'test' or self.data_type == 'val':
            normalized_data = self.val_test_transform(raw_data)

        img, msk = normalized_data['image'], normalized_data['label']
        # msk = msk.squeeze(0)
        # img = self.normalize(img)
        # if self.is_transform:
        #     img, msk = self.transform(rgb_img, mask)
        return img, msk

    # def transform(self, img, mask):
    #     img = self.rgb_transform(img)
    #     # msk = self.mask_transform(mask)
    #     msk = torch.FloatTensor(mask)
    #     return img, msk