import os
import torch
import numpy as np
import scipy.misc as m
from PIL import Image
from torch.utils import data
import scipy.io as sio


class HKUIS_MSRAB(data.Dataset):
    def __init__(self, root='./dataset', set_type='train', transform=None, return_size=False):
        self.root = root
        self.hkuis_root = os.path.join(root, 'HKU-IS')
        self.msrab_root = os.path.join(root, 'MSRA-B')
        self.set_type = set_type
        self.transfrom = transform
        self.return_size = return_size
        self.hkuis_files = {}
        self.msrab_files = {}

        hkuis_mat_path = os.path.join(self.hkuis_root, self.set_type + 'ImgSet.mat')
        msrab_mat_path = os.path.join(self.msrab_root, self.set_type + 'ImgSet.mat')

        hkuis_mat_files = sio.loadmat(hkuis_mat_path)[self.set_type + 'ImgSet']
        msrab_mat_files = sio.loadmat(msrab_mat_path)[self.set_type + 'ImgSet']

        self.hkuis_files[self.set_type] = [hkuis_mat_files[i][0][0][:-4] for i in range(hkuis_mat_files.shape[0])]
        self.msrab_files[self.set_type] = [msrab_mat_files[i][0][0][:-4] for i in range(msrab_mat_files.shape[0])]

        print('There are totally %d images for %s set' %
              (len(self.hkuis_files[self.set_type]) + len(self.msrab_files[self.set_type]), self.set_type))

    def __len__(self):
        return len(self.hkuis_files[self.set_type]) + len(self.msrab_files[self.set_type])

    def __getitem__(self, index):
        if index < len(self.msrab_files[self.set_type]):
            image_name = self.msrab_files[self.set_type][index]
            img_path = os.path.join(self.msrab_root, 'imgs', image_name + '.jpg')
            gt_path = os.path.join(self.msrab_root, 'gt', image_name + '.png')
        else:
            index -= len(self.msrab_files[self.set_type])
            image_name = self.hkuis_files[self.set_type][index]
            img_path = os.path.join(self.hkuis_root, 'imgs', image_name + '.png')
            gt_path = os.path.join(self.hkuis_root, 'gt', image_name + '.png')

        img = Image.open(img_path).convert('RGB')
        weight, height = img.size
        img_size = (height, weight)
        gt = np.array(Image.open(gt_path)) / 255
        gt = Image.fromarray(gt.astype(np.uint8))  # convert to 0 ~ 1
        sample = {'image': img, 'label': gt}
        if self.transfrom:
            sample = self.transfrom(sample)
        if self.return_size:
            sample['size'] = torch.Tensor(img_size)
        return sample