# system include
from numpy.random import normal
import numpy as np
import os
import random
from cStringIO import StringIO
import time
import scipy.misc
from matplotlib import pyplot as plt
from PIL import Image
from model.MobileNet_v2 import MobileNet_v2
import scipy.io as scio
import argparse
import glob
from datetime import datetime
import socket

# torch include
import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
from torch.autograd import Variable
import torchvision.utils as vutils
from torchvision import transforms
from torch.nn import init
from torch.utils import data
import torchvision
from torchvision.utils import make_grid

# tensorboard include
from tensorboardX import SummaryWriter

# model include
from model.deeplab import DeepLab

# tools include
from tools import custom_transforms as ct
from tools.load_pretrain_model import load_pretrain_model
from tools import utils

# data loader include
from data_loader.dataloader import HKUIS_MSRAB

def get_arguments():
    parser = argparse.ArgumentParser()
    parser.add_argument('-model_name', type=str, default='deeplab')
    parser.add_argument('-criterion', type=str, default='BCE')
    parser.add_argument('-num_classes', type=int, default=1)
    parser.add_argument('-batch_size', type=int, default=6)
    parser.add_argument('-total_epochs', type=int, default=500)
    parser.add_argument('-resume_epoch', type=int, default=208)  # the point which we will continue the training
    parser.add_argument('-lr', type=float, default=1e-9)
    parser.add_argument('-weight_decay', type=float, default=5e-4)
    parser.add_argument('-momentum', type=float, default=0.9)
    parser.add_argument('-save_every', type=int, default=1)
    parser.add_argument('-log_cycle', type=int, default=25)
    parser.add_argument('-load_path', type=str, default='')
    parser.add_argument('-run_id', type=int, default=-1)
    parser.add_argument('-use_eval', type=int, default=1)
    parser.add_argument('-input_size', type=int, default=400)  # image size
    return parser.parse_args()

def main(args):
    device_ids = [2]

    save_dir_root = os.path.join(os.path.dirname(os.path.abspath(__file__)))
    if args.resume_epoch != 0:
        runs = sorted(glob.glob(os.path.join(save_dir_root, 'run', 'run_*')))
        run_id = int(runs[-1].split('_')[-1]) if runs else 0
    else:
        runs = sorted(glob.glob(os.path.join(save_dir_root, 'run', 'run_*')))
        run_id = int(runs[-1].split('_')[-1]) + 1 if runs else 0

    if args.run_id >= 0:
        run_id = args.run_id

    save_dir = os.path.join(save_dir_root, 'run', 'run_' + str(run_id))
    log_dir = os.path.join(save_dir, 'models', datetime.now().strftime('%b%d_%H-%M-%S') + '_' + socket.gethostname())
    writer = SummaryWriter(log_dir=log_dir)

    net = DeepLab(nInputChannels=3, n_classes=args.num_classes)
    net.mobilenet_features = load_pretrain_model(net.mobilenet_features, torch.load('./pretrain_model/mobilenet_v2.pth.tar'))
    net = nn.DataParallel(net.cuda(device_ids[0]), device_ids=device_ids)

    if args.resume_epoch == 0:
        print('Training ' + args.model_name + ' from scratch...')
    else:
        load_path = os.path.join(save_dir, 'models', args.model_name + '_epoch-' + str(args.resume_epoch - 1) + '.pth')
        print('Initializing weights from: {}...'.format(load_path))
        net.load_state_dict(torch.load(load_path, map_location=lambda storage, loc: storage))

    optimizer = optim.SGD(net.parameters(), lr=args.lr, momentum=args.momentum,
                          weight_decay=args.weight_decay)

    criterion = nn.BCEWithLogitsLoss(size_average=False)

    train_transform = transforms.Compose([
        ct.FixedResize(size=(args.input_size + 8, args.input_size + 8)),
        ct.RandomCrop(size=(args.input_size, args.input_size)),
        ct.RandomHorizontalFlip(),
        ct.RandomRotateOrthogonal(),
        ct.Normalize(mean=(0.485, 0.456, 0.406), std=(0.229, 0.224, 0.225)),
        ct.ToTensor()])

    test_transform = transforms.Compose([
        ct.FixedResize(size=(args.input_size, args.input_size)),
        ct.Normalize(mean=(0.485, 0.456, 0.406), std=(0.229, 0.224, 0.225)),
        ct.ToTensor()])

    train_dataset = HKUIS_MSRAB(set_type='train', transform=train_transform)
    val_dataset = HKUIS_MSRAB(set_type='val', transform=test_transform)
    train_data_loader = data.DataLoader(train_dataset, batch_size=args.batch_size, shuffle=True, num_workers=40)
    val_data_loader = data.DataLoader(val_dataset, batch_size=args.batch_size, shuffle=False, num_workers=40)

    num_train_iteration = len(train_data_loader)

    num_iteration = args.resume_epoch * num_train_iteration
    num_samples = args.resume_epoch * len(train_dataset)

    print("Current number of iterations: %d" % num_iteration)
    print("current number of samples: %d" % num_samples)

    recent_loss_list = []

    print("Training begins . . .\n\n\n")

    train_start_time = time.time()

    global_num_samples = 0

    for epoch in range(args.resume_epoch, args.total_epochs):
        net.train()
        epoch_loss_list = []
        for idx, batch_samples in enumerate(train_data_loader):
            optimizer.zero_grad()
            imgs, gts = batch_samples['image'], batch_samples['label']
            imgs, gts = Variable(imgs).cuda(device_ids[0]), Variable(gts).cuda(device_ids[0])
            global_num_samples += imgs.data.shape[0]
            num_samples += imgs.data.shape[0]
            outputs = net(imgs)
            loss = criterion(outputs, gts)
            train_loss = loss.item()
            epoch_loss_list.append(train_loss)
            if len(recent_loss_list) < args.log_cycle:
                recent_loss_list.append(train_loss)
            else:
                recent_loss_list[num_iteration % args.log_cycle] = train_loss

            loss.backward()
            optimizer.step()

            num_iteration += 1

            if num_iteration % args.log_cycle == 0:
                recent_mean_loss = sum(recent_loss_list) / len(recent_loss_list)
                print('Epoch: %d, batch idx: %d, recent mean loss: %.2f, having trained: %.2f seconds' %
                      (epoch, idx, recent_mean_loss, time.time() - train_start_time))
                writer.add_scalar('data/train loss', recent_mean_loss, num_samples)

            # show 10 * 3 images per epoch
            if idx % (num_train_iteration // 10) == 0:
                grid_image = make_grid(imgs[:3].clone().cpu().data, 3, normalize=True)
                writer.add_image('Image', grid_image, global_num_samples)

                tmp = torch.nn.Sigmoid()(outputs[:3])
                grid_image = make_grid(utils.decode_seg_map_sequence(tmp.narrow(1, 0, 1).detach().cpu().numpy()), 3,
                                           normalize=False, range=(0, 255))

                writer.add_image('Predicted label', grid_image, global_num_samples)
                grid_image = make_grid(
                    utils.decode_seg_map_sequence(torch.squeeze(gts[:3], 1).detach().cpu().numpy()), 3,
                    normalize=False, range=(0, 255))
                writer.add_image('Groundtruth label', grid_image, global_num_samples)

        epoch_mean_loss = sum(epoch_loss_list) / len(epoch_loss_list)

        print('\nEpoch: %d, mean loss of this epoch: %.2f' % (epoch, epoch_mean_loss))
        writer.add_scalar('data/epoch loss', epoch_mean_loss, epoch)


        # validation
        with torch.no_grad():
            net.eval()
            total_loss = 0.0
            total_mae = 0.0
            prec_list = []
            recall_list = []
            count = 0
            for idx, batch_samples in enumerate(val_data_loader):
                imgs, gts = batch_samples['image'], batch_samples['label']
                imgs, gts = Variable(imgs).cuda(device_ids[0]), Variable(gts).cuda(device_ids[0])
                outputs = net(imgs)
                loss = criterion(outputs, gts)
                total_loss += loss.item()

                predictions = torch.nn.Sigmoid()(outputs)

                total_mae += utils.get_mae(predictions, gts) * predictions.size(0)
                temp_prec_list, temp_recall_list = utils.get_prec_recall(predictions, gts)
                prec_list.extend(temp_prec_list)
                recall_list.extend(temp_recall_list)
                count += predictions.size(0)
            assert(count == len(val_data_loader.dataset))
            avg_mae = total_mae / count
            avg_loss = total_loss / count
            avg_prec = sum(prec_list) / len(prec_list)
            avg_recall = sum(recall_list) / len(recall_list)
            F_beta = 1.3 * avg_prec * avg_recall / (0.3 * avg_prec + avg_recall)
            print('\nValidation:')
            print('Epoch: %d, number of images: %d loss: %.2f mae: %.4f fbeta: %.4f' % (
                epoch, count, avg_loss, avg_mae, F_beta))
            writer.add_scalar('data/validation loss', avg_loss, epoch)
            writer.add_scalar('data/validation mae', avg_mae, epoch)
            writer.add_scalar('data/validation fbeta', F_beta, epoch)

        # save the model
        if epoch % args.save_every == args.save_every - 1:
            save_path = os.path.join(save_dir, 'models', args.model_name + '_epoch-' + str(epoch) + '.pth')
            torch.save(net.state_dict(), save_path)
            print("Save model at {}\n".format(save_path))


if __name__ == '__main__':
    args = get_arguments()
    main(args)