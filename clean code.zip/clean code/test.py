import matplotlib
matplotlib.use('Agg')
import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
from torch.autograd import Variable
from numpy.random import normal
import numpy as np
import os
from torch.nn import init
from torch.utils import data
import torchvision
import random
from cStringIO import StringIO
import time
import scipy.misc
from matplotlib import pyplot as plt
from test_dataloader import MyDataloader
from PIL import Image
from model.deeplab import DeepLab
import torchvision.utils as vutils
import time
import matplotlib.pyplot as plt
from sklearn.metrics import precision_recall_curve
from torchvision import transforms
from tensorboardX import SummaryWriter

# add batch load test imgs

device_ids = [2]
num_epoches = 10
num_of_thresholds = 256
beta = np.sqrt(0.3)
batch_size = 10

test_path = '/home/yangbinbin/temp_msra/test_imgs'
# test_path = '/home/yangbinbin/Merge_dataset/imgs_test'
# test_path = '/home/yangbinbin/HKU-IS/imgs_test'
test_dataset = MyDataloader(test_path, data_type='test')
test_loader = data.DataLoader(test_dataset, batch_size=batch_size, num_workers=40, shuffle=False)


criterion = nn.BCEWithLogitsLoss(size_average=False)

def eval_mae(pred, gt):
    return torch.abs(pred - gt).mean()

def eval_one_threshold(pred, gt, threshold):
    mask = (pred > threshold)
    gt = np.array((gt == 255), dtype=np.float)
    tp = (mask * gt).sum() + 1e-5
    prec, recall = tp / (mask.sum() + 1e-5), tp / gt.sum()
    # F_beta = (1 + beta ** 2) * prec * recall / (beta ** 2 * prec + recall)
    return prec, recall

def eval_mean_threshold(pred, gt):
    threshold = 2 * pred.mean()
    if threshold > 255:
        threshold = 255
    mask = (pred > threshold)
    gt = np.array((gt == 255), dtype=np.float)
    tp = (mask * gt).sum() + 1e-5
    prec, recall = tp / (mask.sum() + 1e-5), tp / gt.sum()
    F_beta = (1 + beta ** 2) * prec * recall / (beta ** 2 * prec + recall)
    return F_beta

def compute_mean_F_measure(gts, masks, epoch):
    data_size = len(gts)

    F_beta_measure = 0.0
    for idx in range(0, data_size):
        gt = gts[idx]
        mask = masks[idx]
        F_measure = eval_mean_threshold(mask, gt)
        F_beta_measure += F_measure
    F_beta_measure /= data_size
    print('Mean F-measure: %f' % F_beta_measure)

def compute_max_F_measure(gts, masks, avg_mae, epoch):
    data_size = len(gts)

    prec_list = []
    recall_list = []
    F_beta_list = []

    for threshold in range(0, 256):
        one_thresh_prec = 0.0
        one_thresh_recall = 0.0
        for idx in range(0, data_size):
            gt = gts[idx]   # 0~255
            mask = masks[idx]   # 0~255
            temp_prec, temp_recall = eval_one_threshold(mask, gt, threshold)
            one_thresh_prec += temp_prec
            one_thresh_recall += temp_recall
        # First we compute the average prec and recall and then comput F-measure
        one_thresh_prec /= data_size
        one_thresh_recall /= data_size
        one_thresh_F_beta = (1 + beta ** 2) * one_thresh_prec * one_thresh_recall / (
                    beta ** 2 * one_thresh_prec + one_thresh_recall)
        prec_list.append(one_thresh_prec)
        recall_list.append(one_thresh_recall)
        F_beta_list.append(one_thresh_F_beta)

    prec_list = np.array(prec_list)
    recall_list = np.array(recall_list)
    F_beta_list = np.array(F_beta_list)
    index = np.argmax(F_beta_list)
    print('\nEpoch: %d' % epoch)
    print('Max F-measure: %f' % F_beta_list[index])
    print('Precision: %f' % prec_list[index])
    print('Recall: %f' % recall_list[index])
    print('MAE: %f' % avg_mae)



def test(model, criterion, test_loader, epoch):
    model.eval()
    data_size = len(test_loader.dataset)


    with torch.no_grad():
        gts = []
        masks = []

        avg_mae = 0.0

        for idx, data in enumerate(test_loader):
            print idx  # print the computing idx
            temp_rgb_img, temp_gt = data
            temp_rgb_img, temp_gt = temp_rgb_img.cuda(device_ids[0]), temp_gt.cuda(device_ids[0])
            temp_output = model(temp_rgb_img)
            temp_output = nn.Sigmoid()(temp_output)

            for i in range(temp_output.shape[0]):
                gt = temp_gt[i, :]
                rgb_img = temp_rgb_img[i]
                output = temp_output[i, :]  # one output is C, H, W
                gt = gt.squeeze(0)
                float_output, float_gt = output.squeeze(0).view(-1), gt.view(-1)
                mae = eval_mae(float_output, float_gt)
                avg_mae += mae

                flatten_output = np.array(transforms.ToPILImage()(output.cpu())).flatten()  # convert to 0~255
                flatten_gt = (gt * 255).flatten()  # convert to 0~255
                flatten_gt = flatten_gt.cpu().numpy()
                gts.append(flatten_gt)  # 0~255
                masks.append(flatten_output)   # 0~255

                # save test result
                vutils.save_image(rgb_img, './test_samples/test_batch_idx_%d_num_%d_epoch_%d.png' % (idx, i, epoch),
                                  normalize=True)
                print_gt = Image.fromarray(np.uint8(gt.cpu().numpy() * 255), mode='L')
                print_gt.save('./test_samples/test_gt_batch_idx_%d_num_%d_epoch_%d.png' % (idx, i, epoch))
                vutils.save_image(output.data, './test_samples/test_pred_mask_batch_idx_%d_num_%d_epoch_%d.png' % (idx, i, epoch),
                                  normalize=False)



        gts = np.array(gts)
        masks = np.array(masks)
        avg_mae /= data_size
        print 'comuting max F'
        compute_max_F_measure(gts, masks, avg_mae, epoch)
        print 'computing mean F'
        compute_mean_F_measure(gts, masks, epoch)


model = DeepLab()
model = nn.DataParallel(model.cuda(device_ids[0]), device_ids=device_ids)
model.load_state_dict(torch.load('./deeplab_epoch-201.pth', map_location=lambda storage, loc: storage))

test(model, criterion, test_loader, 201)
